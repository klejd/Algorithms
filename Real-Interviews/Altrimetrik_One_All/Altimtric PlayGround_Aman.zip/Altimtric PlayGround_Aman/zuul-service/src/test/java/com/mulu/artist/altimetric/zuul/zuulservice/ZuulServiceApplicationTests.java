package com.mulu.artist.altimetric.zuul.zuulservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

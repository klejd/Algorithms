package alti.com.toptrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToptrackApplicationTests {

	@Test
	void contextLoads() {
	}

}

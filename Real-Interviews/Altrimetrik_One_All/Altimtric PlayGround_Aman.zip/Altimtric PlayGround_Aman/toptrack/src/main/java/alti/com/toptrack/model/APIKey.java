package alti.com.toptrack.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode
public class APIKey {
    private String lastfm="4d47df5877d74d11d04ba5ac8a45cfde";
    private String musixmatch="6c859ffa2529964f091634fc989740f4";

    private String goolge = "AIzaSyBQkPWAl8ji1b6qMgIJruouay1m5mjuLP0";
    private String cx = "009976367278009039396:la-yg83ejjg";

}

package alti.playground.explorecountry.dto;

 public enum ErrorType {

    INTERNAL, VALIDATION, GENERAL;

}
